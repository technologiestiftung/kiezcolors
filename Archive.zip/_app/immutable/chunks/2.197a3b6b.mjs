import{_ as r}from"./_page.ed77219c.mjs";import{default as t}from"../entry/_page.svelte.ba7f025d.mjs";export{t as component,r as universal};
