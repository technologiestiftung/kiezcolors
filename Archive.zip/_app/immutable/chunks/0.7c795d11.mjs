import{_ as r}from"./_layout.da46b06b.mjs";import{default as t}from"../entry/_layout.svelte.cc4ad5eb.mjs";export{t as component,r as universal};
