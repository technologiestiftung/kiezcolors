import{default as t}from"../entry/error.svelte.937d797c.mjs";export{t as component};
