import{default as t}from"../entry/error.svelte.25e038a1.mjs";export{t as component};
